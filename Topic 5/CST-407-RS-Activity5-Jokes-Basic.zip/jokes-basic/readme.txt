This is starting code for a simple PHP and mySQL application.  Save your best jokes and share them with friends.

Based on a tutorial at https://www.youtube.com/watch?v=6xedgVwYuAg&list=PLhPyEFL5u-i0XXGLJawaTNLiXxmSp24TR 

You will need a text editor and a web and database server to make this applicaiton work. I recommend MAMP (http://www.mamp.info) for a web and database server.

the data.sql file will provide you with a starting database.