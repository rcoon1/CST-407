This is a website to demonstrate hacking techniques using cross site scripting.  This site, along with
the victim site work together in a lesson.  Video tutorials can be found at youtube.com/shadsluiter or
in the readme.docx instructions.

Shad Sluiter