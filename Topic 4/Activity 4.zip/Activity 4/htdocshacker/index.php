<html>
<body>

<h1>Post a comment</h1>
<form action="http://victimsite.com/index.php" method="post"> 
<label for="comment_title">Comment Title</label>
<input type="text" name="comment_title"><br/>
<label for="comment_text">Text</label> 
<textarea name="comment_text" cols="30" rows="10"></textarea>
<br/>
<input type="submit" name="submit">
</form>
</body>

</html>