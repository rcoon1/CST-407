<!DOCTYPE html>
<html>
<head>

</head>
<body>
    <h2>Secure page</h2>
    <p>This is a secure page that only logged in users should be able to view.</p>
    <p>If you somehow arrived here without logging in first, you will be charged with illegal entry.</p>
    <p>Thank you -- the management</p>
</body>
</html>