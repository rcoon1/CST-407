This is a simple login form and secure page application. 
It is a starting point for a tutorial on using session variables and capturing packets using wireshark.